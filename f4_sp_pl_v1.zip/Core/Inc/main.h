/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
////////////////////////////////////////////////////////////////
#include"SimpleMain.h"
////////////////////////////////////////////////////////////////
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define Key1_Pin GPIO_PIN_0
#define Key1_GPIO_Port GPIOC
#define Key2_Pin GPIO_PIN_1
#define Key2_GPIO_Port GPIOC
#define SPI1_CS_Pin GPIO_PIN_4
#define SPI1_CS_GPIO_Port GPIOA
#define OLED0961_SPI_RES_Pin GPIO_PIN_4
#define OLED0961_SPI_RES_GPIO_Port GPIOC
#define OLED0961_SPI_DC_Pin GPIO_PIN_5
#define OLED0961_SPI_DC_GPIO_Port GPIOC
#define Key5_Pin GPIO_PIN_7
#define Key5_GPIO_Port GPIOE
#define Key6_Pin GPIO_PIN_8
#define Key6_GPIO_Port GPIOE
#define SPI2_CS_Pin GPIO_PIN_10
#define SPI2_CS_GPIO_Port GPIOE
#define Motor1_Ain1_Pin GPIO_PIN_12
#define Motor1_Ain1_GPIO_Port GPIOE
#define Motor1_Ain2_Pin GPIO_PIN_13
#define Motor1_Ain2_GPIO_Port GPIOE
#define Motor1_Bin1_Pin GPIO_PIN_14
#define Motor1_Bin1_GPIO_Port GPIOE
#define Motor1_Bin1_EXTI_IRQn EXTI15_10_IRQn
#define Motor1_Bin2_Pin GPIO_PIN_15
#define Motor1_Bin2_GPIO_Port GPIOE
#define Motor2_Ain1_Pin GPIO_PIN_12
#define Motor2_Ain1_GPIO_Port GPIOB
#define Motor2_Ain2_Pin GPIO_PIN_13
#define Motor2_Ain2_GPIO_Port GPIOB
#define Motor2_Bin1_Pin GPIO_PIN_14
#define Motor2_Bin1_GPIO_Port GPIOB
#define Motor2_Bin2_Pin GPIO_PIN_15
#define Motor2_Bin2_GPIO_Port GPIOB
#define LED2_R_Pin GPIO_PIN_9
#define LED2_R_GPIO_Port GPIOD
#define LED2_G_Pin GPIO_PIN_10
#define LED2_G_GPIO_Port GPIOD
#define LED2_B_Pin GPIO_PIN_11
#define LED2_B_GPIO_Port GPIOD
#define Key7_Pin GPIO_PIN_14
#define Key7_GPIO_Port GPIOD
#define Key8_Pin GPIO_PIN_15
#define Key8_GPIO_Port GPIOD
#define LED3_R_Pin GPIO_PIN_6
#define LED3_R_GPIO_Port GPIOG
#define LED3_G_Pin GPIO_PIN_7
#define LED3_G_GPIO_Port GPIOG
#define LED3_B_Pin GPIO_PIN_8
#define LED3_B_GPIO_Port GPIOG
#define LED1_R_Pin GPIO_PIN_8
#define LED1_R_GPIO_Port GPIOA
#define LED1_G_Pin GPIO_PIN_11
#define LED1_G_GPIO_Port GPIOA
#define LED1_B_Pin GPIO_PIN_12
#define LED1_B_GPIO_Port GPIOA
#define Key3_Pin GPIO_PIN_6
#define Key3_GPIO_Port GPIOD
#define Key4_Pin GPIO_PIN_7
#define Key4_GPIO_Port GPIOD
#define MPU6050_Interrupt_Pin GPIO_PIN_15
#define MPU6050_Interrupt_GPIO_Port GPIOG
#define MPU6050_Interrupt_EXTI_IRQn EXTI15_10_IRQn

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
