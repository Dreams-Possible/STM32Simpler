Main/SimpleOLED096s_IIC.o: ../Main/SimpleOLED096s_IIC.c \
 ../Main/SimpleOLED096s_IIC.h
../Main/SimpleOLED096s_IIC.h:
