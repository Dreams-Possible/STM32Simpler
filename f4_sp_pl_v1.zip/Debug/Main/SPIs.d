Main/SPIs.o: ../Main/SPIs.c ../Main/SPIs.h ../Main/SimpleMain.h \
 ../Core/Inc/main.h ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h \
 ../Core/Inc/stm32f4xx_hal_conf.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f407xx.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_adc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h \
 C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.18.0/f4_sp_pl_v1/Main/SimpleMain.h \
 ../Main/LEDs.h ../Main/Keys.h ../Main/UARTs.h ../Main/Timers.h \
 ../Main/IICs.h ../Main/OLED096_Character.h ../Main/SimpleOLED096s_IIC.h \
 ../Main/SimpleOLED096s_SPI.h ../Main/OLED096s_IIC.h \
 ../Main/OLED096s_SPI.h ../Main/OLED096s_GUI.h ../Main/Encoders.h \
 ../Main/Motors.h \
 C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.18.0/f4_sp_pl_v1/Main/MPU6050/MPU6050.h \
 ../Main/W25Qx.h
../Main/SPIs.h:
../Main/SimpleMain.h:
../Core/Inc/main.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h:
../Core/Inc/stm32f4xx_hal_conf.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f407xx.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_adc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h:
C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.18.0/f4_sp_pl_v1/Main/SimpleMain.h:
../Main/LEDs.h:
../Main/Keys.h:
../Main/UARTs.h:
../Main/Timers.h:
../Main/IICs.h:
../Main/OLED096_Character.h:
../Main/SimpleOLED096s_IIC.h:
../Main/SimpleOLED096s_SPI.h:
../Main/OLED096s_IIC.h:
../Main/OLED096s_SPI.h:
../Main/OLED096s_GUI.h:
../Main/Encoders.h:
../Main/Motors.h:
C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.18.0/f4_sp_pl_v1/Main/MPU6050/MPU6050.h:
../Main/W25Qx.h:
