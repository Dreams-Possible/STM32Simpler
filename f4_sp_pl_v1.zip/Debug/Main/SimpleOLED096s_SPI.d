Main/SimpleOLED096s_SPI.o: ../Main/SimpleOLED096s_SPI.c \
 ../Main/SimpleOLED096s_SPI.h
../Main/SimpleOLED096s_SPI.h:
