Main/Other/USART_JDY31.o: ../Main/Other/USART_JDY31.c \
 ../Main/Other/USART_JDY31.h
../Main/Other/USART_JDY31.h:
