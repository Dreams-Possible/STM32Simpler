Main/Other/Infrared.o: ../Main/Other/Infrared.c ../Main/Other/Infrared.h
../Main/Other/Infrared.h:
