Main/Other/USART_UART.o: ../Main/Other/USART_UART.c \
 ../Main/Other/USART_UART.h
../Main/Other/USART_UART.h:
