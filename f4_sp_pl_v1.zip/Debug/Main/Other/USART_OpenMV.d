Main/Other/USART_OpenMV.o: ../Main/Other/USART_OpenMV.c \
 ../Main/Other/USART_OpenMV.h
../Main/Other/USART_OpenMV.h:
