################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Main/Other/ADC.c \
../Main/Other/Controller.c \
../Main/Other/HCSR04.c \
../Main/Other/Infrared.c \
../Main/Other/MainSystem.c \
../Main/Other/SYN6288.c \
../Main/Other/ServoMotors.c \
../Main/Other/SimpleIO.c \
../Main/Other/USART_JDY31.c \
../Main/Other/USART_OpenMV.c \
../Main/Other/USART_UART.c 

OBJS += \
./Main/Other/ADC.o \
./Main/Other/Controller.o \
./Main/Other/HCSR04.o \
./Main/Other/Infrared.o \
./Main/Other/MainSystem.o \
./Main/Other/SYN6288.o \
./Main/Other/ServoMotors.o \
./Main/Other/SimpleIO.o \
./Main/Other/USART_JDY31.o \
./Main/Other/USART_OpenMV.o \
./Main/Other/USART_UART.o 

C_DEPS += \
./Main/Other/ADC.d \
./Main/Other/Controller.d \
./Main/Other/HCSR04.d \
./Main/Other/Infrared.d \
./Main/Other/MainSystem.d \
./Main/Other/SYN6288.d \
./Main/Other/ServoMotors.d \
./Main/Other/SimpleIO.d \
./Main/Other/USART_JDY31.d \
./Main/Other/USART_OpenMV.d \
./Main/Other/USART_UART.d 


# Each subdirectory must supply rules for building sources it contributes
Main/Other/%.o Main/Other/%.su Main/Other/%.cyclo: ../Main/Other/%.c Main/Other/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.18.0/f4_sp_pl_v1/Main" -I"C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.18.0/f4_sp_pl_v1/Main/MPU6050" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Main-2f-Other

clean-Main-2f-Other:
	-$(RM) ./Main/Other/ADC.cyclo ./Main/Other/ADC.d ./Main/Other/ADC.o ./Main/Other/ADC.su ./Main/Other/Controller.cyclo ./Main/Other/Controller.d ./Main/Other/Controller.o ./Main/Other/Controller.su ./Main/Other/HCSR04.cyclo ./Main/Other/HCSR04.d ./Main/Other/HCSR04.o ./Main/Other/HCSR04.su ./Main/Other/Infrared.cyclo ./Main/Other/Infrared.d ./Main/Other/Infrared.o ./Main/Other/Infrared.su ./Main/Other/MainSystem.cyclo ./Main/Other/MainSystem.d ./Main/Other/MainSystem.o ./Main/Other/MainSystem.su ./Main/Other/SYN6288.cyclo ./Main/Other/SYN6288.d ./Main/Other/SYN6288.o ./Main/Other/SYN6288.su ./Main/Other/ServoMotors.cyclo ./Main/Other/ServoMotors.d ./Main/Other/ServoMotors.o ./Main/Other/ServoMotors.su ./Main/Other/SimpleIO.cyclo ./Main/Other/SimpleIO.d ./Main/Other/SimpleIO.o ./Main/Other/SimpleIO.su ./Main/Other/USART_JDY31.cyclo ./Main/Other/USART_JDY31.d ./Main/Other/USART_JDY31.o ./Main/Other/USART_JDY31.su ./Main/Other/USART_OpenMV.cyclo ./Main/Other/USART_OpenMV.d ./Main/Other/USART_OpenMV.o ./Main/Other/USART_OpenMV.su ./Main/Other/USART_UART.cyclo ./Main/Other/USART_UART.d ./Main/Other/USART_UART.o ./Main/Other/USART_UART.su

.PHONY: clean-Main-2f-Other

