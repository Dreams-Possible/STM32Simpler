Main/Other/MainSystem.o: ../Main/Other/MainSystem.c \
 ../Main/Other/MainSystem.h
../Main/Other/MainSystem.h:
