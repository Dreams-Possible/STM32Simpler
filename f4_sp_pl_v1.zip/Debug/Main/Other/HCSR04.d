Main/Other/HCSR04.o: ../Main/Other/HCSR04.c ../Main/Other/HCSR04.h
../Main/Other/HCSR04.h:
