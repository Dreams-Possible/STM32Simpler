Main/Other/SimpleIO.o: ../Main/Other/SimpleIO.c ../Main/Other/SimpleIO.h
../Main/Other/SimpleIO.h:
