Main/Other/Controller.o: ../Main/Other/Controller.c \
 ../Main/Other/Controller.h
../Main/Other/Controller.h:
