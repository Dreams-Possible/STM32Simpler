Main/Other/ADC.o: ../Main/Other/ADC.c ../Main/Other/ADC.h
../Main/Other/ADC.h:
