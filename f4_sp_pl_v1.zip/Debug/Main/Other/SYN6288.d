Main/Other/SYN6288.o: ../Main/Other/SYN6288.c ../Main/Other/SYN6288.h
../Main/Other/SYN6288.h:
