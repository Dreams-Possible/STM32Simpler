################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Main/MPU6050/MPU6050.c \
../Main/MPU6050/inv_mpu.c \
../Main/MPU6050/inv_mpu_dmp_motion_driver.c 

OBJS += \
./Main/MPU6050/MPU6050.o \
./Main/MPU6050/inv_mpu.o \
./Main/MPU6050/inv_mpu_dmp_motion_driver.o 

C_DEPS += \
./Main/MPU6050/MPU6050.d \
./Main/MPU6050/inv_mpu.d \
./Main/MPU6050/inv_mpu_dmp_motion_driver.d 


# Each subdirectory must supply rules for building sources it contributes
Main/MPU6050/%.o Main/MPU6050/%.su Main/MPU6050/%.cyclo: ../Main/MPU6050/%.c Main/MPU6050/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.18.0/f4_sp_pl_v1/Main" -I"C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.18.0/f4_sp_pl_v1/Main/MPU6050" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Main-2f-MPU6050

clean-Main-2f-MPU6050:
	-$(RM) ./Main/MPU6050/MPU6050.cyclo ./Main/MPU6050/MPU6050.d ./Main/MPU6050/MPU6050.o ./Main/MPU6050/MPU6050.su ./Main/MPU6050/inv_mpu.cyclo ./Main/MPU6050/inv_mpu.d ./Main/MPU6050/inv_mpu.o ./Main/MPU6050/inv_mpu.su ./Main/MPU6050/inv_mpu_dmp_motion_driver.cyclo ./Main/MPU6050/inv_mpu_dmp_motion_driver.d ./Main/MPU6050/inv_mpu_dmp_motion_driver.o ./Main/MPU6050/inv_mpu_dmp_motion_driver.su

.PHONY: clean-Main-2f-MPU6050

