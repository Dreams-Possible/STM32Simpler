################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Main/Encoders.c \
../Main/ExternalInterrupt.c \
../Main/IICs.c \
../Main/Keys.c \
../Main/LEDs.c \
../Main/Motors.c \
../Main/OLED096_Character.c \
../Main/OLED096s_GUI.c \
../Main/OLED096s_IIC.c \
../Main/OLED096s_SPI.c \
../Main/SPIs.c \
../Main/SimpleMain.c \
../Main/SimpleOLED096s_IIC.c \
../Main/SimpleOLED096s_SPI.c \
../Main/Timers.c \
../Main/UARTs.c \
../Main/USARTInterrupt.c \
../Main/W25Qx.c 

OBJS += \
./Main/Encoders.o \
./Main/ExternalInterrupt.o \
./Main/IICs.o \
./Main/Keys.o \
./Main/LEDs.o \
./Main/Motors.o \
./Main/OLED096_Character.o \
./Main/OLED096s_GUI.o \
./Main/OLED096s_IIC.o \
./Main/OLED096s_SPI.o \
./Main/SPIs.o \
./Main/SimpleMain.o \
./Main/SimpleOLED096s_IIC.o \
./Main/SimpleOLED096s_SPI.o \
./Main/Timers.o \
./Main/UARTs.o \
./Main/USARTInterrupt.o \
./Main/W25Qx.o 

C_DEPS += \
./Main/Encoders.d \
./Main/ExternalInterrupt.d \
./Main/IICs.d \
./Main/Keys.d \
./Main/LEDs.d \
./Main/Motors.d \
./Main/OLED096_Character.d \
./Main/OLED096s_GUI.d \
./Main/OLED096s_IIC.d \
./Main/OLED096s_SPI.d \
./Main/SPIs.d \
./Main/SimpleMain.d \
./Main/SimpleOLED096s_IIC.d \
./Main/SimpleOLED096s_SPI.d \
./Main/Timers.d \
./Main/UARTs.d \
./Main/USARTInterrupt.d \
./Main/W25Qx.d 


# Each subdirectory must supply rules for building sources it contributes
Main/%.o Main/%.su Main/%.cyclo: ../Main/%.c Main/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.18.0/f4_sp_pl_v1/Main" -I"C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.18.0/f4_sp_pl_v1/Main/MPU6050" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Main

clean-Main:
	-$(RM) ./Main/Encoders.cyclo ./Main/Encoders.d ./Main/Encoders.o ./Main/Encoders.su ./Main/ExternalInterrupt.cyclo ./Main/ExternalInterrupt.d ./Main/ExternalInterrupt.o ./Main/ExternalInterrupt.su ./Main/IICs.cyclo ./Main/IICs.d ./Main/IICs.o ./Main/IICs.su ./Main/Keys.cyclo ./Main/Keys.d ./Main/Keys.o ./Main/Keys.su ./Main/LEDs.cyclo ./Main/LEDs.d ./Main/LEDs.o ./Main/LEDs.su ./Main/Motors.cyclo ./Main/Motors.d ./Main/Motors.o ./Main/Motors.su ./Main/OLED096_Character.cyclo ./Main/OLED096_Character.d ./Main/OLED096_Character.o ./Main/OLED096_Character.su ./Main/OLED096s_GUI.cyclo ./Main/OLED096s_GUI.d ./Main/OLED096s_GUI.o ./Main/OLED096s_GUI.su ./Main/OLED096s_IIC.cyclo ./Main/OLED096s_IIC.d ./Main/OLED096s_IIC.o ./Main/OLED096s_IIC.su ./Main/OLED096s_SPI.cyclo ./Main/OLED096s_SPI.d ./Main/OLED096s_SPI.o ./Main/OLED096s_SPI.su ./Main/SPIs.cyclo ./Main/SPIs.d ./Main/SPIs.o ./Main/SPIs.su ./Main/SimpleMain.cyclo ./Main/SimpleMain.d ./Main/SimpleMain.o ./Main/SimpleMain.su ./Main/SimpleOLED096s_IIC.cyclo ./Main/SimpleOLED096s_IIC.d ./Main/SimpleOLED096s_IIC.o ./Main/SimpleOLED096s_IIC.su ./Main/SimpleOLED096s_SPI.cyclo ./Main/SimpleOLED096s_SPI.d ./Main/SimpleOLED096s_SPI.o ./Main/SimpleOLED096s_SPI.su ./Main/Timers.cyclo ./Main/Timers.d ./Main/Timers.o ./Main/Timers.su ./Main/UARTs.cyclo ./Main/UARTs.d ./Main/UARTs.o ./Main/UARTs.su ./Main/USARTInterrupt.cyclo ./Main/USARTInterrupt.d ./Main/USARTInterrupt.o ./Main/USARTInterrupt.su ./Main/W25Qx.cyclo ./Main/W25Qx.d ./Main/W25Qx.o ./Main/W25Qx.su

.PHONY: clean-Main

